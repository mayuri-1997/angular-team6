import { Component, OnInit } from '@angular/core';

import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';





@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {







  public fbFormGroup = this.fb.group({
    username: ['', Validators.required],
    password: ['', Validators.required],
  });




  constructor(private fb: FormBuilder, private router: Router, private http: HttpClient) { }

  ngOnInit(): void { }
  async resethere() {
    const data = this.fbFormGroup.value;
    const url = 'http://localhost:3000/updateuser';

    let result = await this.http.post(url, data).toPromise();

    console.log(result);

    //this.router.navigate(['login']);


  }


}
