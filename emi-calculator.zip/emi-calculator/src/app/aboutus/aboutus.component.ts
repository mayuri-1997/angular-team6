import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {

  emi: any;

  public fbFormGroup = this.fb.group({
    principal: [''],
    rate: [''],
    period: [''],

  });




  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
  }

  calculatehere() {
    const data = this.fbFormGroup.value;
    console.log(data);

    const grandtotal = data.principal * (1 + (data.rate / 100) * data.period);
    console.log(grandtotal);
    this.emi = grandtotal / (data.period * 12);
    console.log(this.emi);

    // const emi = (data.principal * (data.rate / 1200) * ((1 + (data.rate / 1200)) ^ (data.period * 12))) /
    //   ((1 + (data.rate / 1200)) ^ (data.period * 12) - 1);
    //  console.log(emi);

  }

}
