const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors()); // unblocking cors policy
app.use(express.json()); // BODY :: RAW :: JSON
//app.use(express.urlencoded({ extended: true })); // BODY :: URL ENCODED

const dbadduser = require("./add");





// POST API :: FOR TESTIG POSTMAN :: ANDROID :: IOS :: BROWSER
// http://localhost:3000/adduser
app.post("/adduser1", async (req, res) => {
    try {
        const input = req.body; // before doing this

        await dbadduser.addUser(input);
        res.json({ message: "success post" });
    } catch (err) {
        res.json({ message: "failure post" });
    }
});


app.post("/updateuser", async (req, res) => {
    try {
        const input = req.body; // before doing this

        await dbadduser.updateinfo(input);
        res.json({ message: "success post" });
    } catch (err) {
        res.json({ message: "failure post" });
    }
});




// started teh server.

app.listen(3000);