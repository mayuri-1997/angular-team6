const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const DB_CONFIG = {

    host: "localhost",
    user: "root",
    password: "mayuri@1234",
    database: "myproject",

};

let addUser = async (input) => {
    const Connection = mysql.createConnection(DB_CONFIG);
    await Connection.connectAsync();

    let sql =
        "insert into userdata(username,password,email,mobile) values(?,?,?,?)";
    let result = await Connection.queryAsync(sql, [
        input.username,
        input.password,
        input.email,
        input.mobile,

    ]);
    console.log(result);





    await Connection.endAsync();


};

//addUser();
module.exports = { addUser };