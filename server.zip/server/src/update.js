const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const DB_CONFIG = {

    host: "localhost",
    user: "root",
    password: "mayuri@1234",
    database: "myproject",

};
let updateinfo = async (input) => {
    const Connection = mysql.createConnection(DB_CONFIG);
    await Connection.connectAsync();

    let sql =
        "update userdata set username=? where password=?";
    let result = await Connection.queryAsync(sql, [
        input.username,
        input.password,

    ]);
    console.log(result);

    await Connection.endAsync();
};

// updateinfo({
//     name="mona",
//     id: "1234",
// });

module.exports = { updateinfo };